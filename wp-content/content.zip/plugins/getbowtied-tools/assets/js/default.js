jQuery(function($) {

	"use strict";



	$(document).on("click", ".open-plugin-details-modal", function(e) {
		console.log('test');
	})
})