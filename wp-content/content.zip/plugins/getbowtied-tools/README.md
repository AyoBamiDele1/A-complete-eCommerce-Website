# GetBowtied-Tools [![Codacy Badge](https://api.codacy.com/project/badge/Grade/25868176da99466c9d383ae0b743dde7)](https://www.codacy.com?utm_source=github.com&amp;utm_medium=referral&amp;utm_content=getbowtied/GetBowtied-Tools&amp;utm_campaign=Badge_Grade)

# Changelog
All notable changes to this project will be documented in this file.

## [2.3.2] - 2017-11-13
### Added
- New - Importer split into 25-28 second chunks to avoid import script dying due to low execution times
- Recommended max execution time changed to 30s


## [2.3.1] - 2017-10-25
### Added
- Fixed a bug sometimes preventing theme update even though a license was activated
- Fixed a bug with the demo import "try again" button
- Fixed a style issue when the theme required more than 4 plugins

